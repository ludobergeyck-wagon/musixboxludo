class CameraController < ApplicationController
  def show
  end
end
