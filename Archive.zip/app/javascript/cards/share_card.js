console.log("share card js loaded")

import html2canvas from "html2canvas"

console.log("share_card.js loaded with html2canvas:", html2canvas)


// ============================================
    // FONCTION 1 : Partager les résultats
    // ============================================
window.shareResults = function () {
      if (navigator.share) {
        navigator.share({
          title: 'Mes résultats MusixBox',
          text: 'J\'ai terminé ma session sur MusixBox ! 🎵',
          url: window.location.href
        });
      } else {
        navigator.clipboard.writeText(window.location.href)
          .then(() => alert('Lien copié ! Collez-le pour partager.'));
      }
    }
    
    // ============================================
    // FONCTION 2 : Sauvegarder la card complète
    // ============================================
    // Cette fonction capture la card (photo + textes) en une seule image
window.savePhoto = function () {
      // On récupère l'élément card-result (la card avec photo + textes)
      const cardElement = document.querySelector(".card-result")
      
      if (!cardElement) {
        alert("Pas de card à sauvegarder")
        return
      }
      
      // html2canvas capture l'élément HTML comme une image
      // C'est comme faire une capture d'écran d'un élément précis
      html2canvas(cardElement, {
        useCORS: true,           // Pour les images externes
        allowTaint: true,        // Permet les images locales
        backgroundColor: null,   // Fond transparent
        scale: 2                 // Qualité x2 pour une meilleure résolution
      }).then(function(canvas) {
        // On convertit le canvas en image PNG
        const imageData = canvas.toDataURL("image/png")
        
        // On crée un lien invisible pour télécharger
        const link = document.createElement("a")
        link.href = imageData
        link.download = `musixbox_${Date.now()}.png`
        
        // On simule un clic pour télécharger
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
        
      }).catch(function(error) {
        console.error("Erreur de capture:", error)
        alert("Erreur lors de la sauvegarde")
      })
    }